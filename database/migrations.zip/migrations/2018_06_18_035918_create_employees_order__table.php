<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeesOrderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees_order', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('employee_id')->unsigned();
            $table->foreign('employee_id')->references('id')->on('employees');
            $table->string('phap_nhan');
            $table->string('san_pham');
            $table->string('status_hr20');
            $table->integer('salary_base');
            $table->integer('salary_action');
            $table->integer('salary_working_day');
            $table->integer('salary_working_ot_time');
            $table->integer('salary_sub');
            $table->integer('salary_other');
            $table->integer('com');
            $table->integer('bonus');
            $table->integer('rent');
            $table->integer('interest');
            $table->integer('bao_hiem');
            $table->integer('giam_tru_ban_than');
            $table->integer('giam_tru_nguoi_phu_thuoc');
            $table->integer('thu_nhap_khong_chiu_thue');
            $table->integer('tong_giam_tru_tinh_thue');
            $table->integer('thu_nhap_tinh_thue');
            $table->integer('tncn');
            $table->integer('thuc_nhan');
            $table->string('cdt');
            $table->integer('order_id')->unsigned();
            $table->foreign('order_id')->references('id')->on('order_info');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees_order');
    }
}
